package cn.com.offcn.day04;

import java.util.Scanner;

public class GameStart {
    public static void main(String[] args) {
        Player p1 = createPlayer();
        while(p1.getName().equals("")) {
            System.out.println("���1�������Ϸ�");
            p1 = createPlayer();
        }
        Player p2 = createPlayer();
        while (p2.getName().equals("") || p2.getName().equals(p1.getName())) {
            System.out.println("���2�������Ϸ�");
            p2 = createPlayer();
        }
        int turn = 1;
        int max = 0;
        Map map = new Map();
        map.createMap();
        while(max < 100) {
            System.out.println();
            System.out.println("��ǰ���1λ��Ϊ" + p1.getLocal() +"���2λ��Ϊ" + p2.getLocal());
            Game.gameOn(turn,p1,p2,map);
            int local1 = p1.getLocal();
            int local2 = p2.getLocal();
            if (local1 > local2) {
                max = local1;
            }else {
                max = local2;
            }
            turn++;
        }
        if (p1.getLocal() > p2.getLocal()) {
            System.out.println("��ϲ��ң�" + p1.getName() +"���ʤ��");
        }else{
            System.out.println("��ϲ��ң�" + p2.getName() +"���ʤ��");
        }
    }

    public static Player createPlayer () {
        System.out.println("��ѡ����Ľ�ɫ");
        System.out.println("##################################");
        System.out.println("1.���   2.��ɭ");
        PlayEnum play2 = PlayEnum.��ɭ;
        PlayEnum play1 = PlayEnum.���;
        Scanner sc = new Scanner(System.in);
        int i = 0;
        try {
            i = sc.nextInt();
        } catch (Exception e) {
            System.out.println("���벻�Ϸ�������������");
            createPlayer();
        }
        if (i == 1) {
            System.out.println("������ɫ" + play1.name());
            Player p1 = new Player(play1.name(), 0);
            System.out.println(p1.getName());
            return p1;
        }else if (i == 2){
            return new Player(play2.name(),0);
        } else {
            System.out.println("��ѡ��ϵͳ�д��ڵĽ�ɫ");
            return new Player("",0);
        }
    }
}
