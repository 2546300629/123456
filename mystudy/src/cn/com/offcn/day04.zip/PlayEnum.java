package cn.com.offcn.day04;

public enum PlayEnum {
    ���("���",1),
    ��ɭ("��ɭ",2);
    private String name;
    private int key;
    private PlayEnum(String name, int key) {
        this.name = name;
        this.key = key;
    }
}
